

<?php $__env->startSection('content'); ?>
    <h2>Song bearbeiten</h2>

    <form class="row" action="/songs/<?php echo e($song->id); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <div class="col-md-6">
        <div class="mb-3">
          <label class="form-label" for="title">Titel</label>
          <input class="form-control" type="text" name="title" id="title" value="<?php echo e($song->title); ?>">
        </div>
        <div class="mb-3">
          <label class="form-label" for="band">Band</label>
          <input class="form-control" type="text" name="band" id="band" value="<?php echo e($song->band); ?>">
        </div>
      </div>

      <div class="col-md-6">
        <div class="mb-3">
          <label class="form-label" for="label">Label</label>
          <select class="form-select" name="labels_id_ref" id="label">
            <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($label->id === $song->labels_id_ref): ?> selected <?php endif; ?> value="<?php echo e($label->id); ?>"><?php echo e($label->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mt-5">
          <button class="btn btn-success" type="submit">Änderung speichern</button>
        </div>
        
        
        <?php if($errors->any()): ?>
          <div class="alert alert-danger mt-5">
            <ul class="list-group">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item bg-transparent"> <?php echo $error; ?> </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>
      </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gencay\Documents\laravel-projekte\laravel-rest\resources\views/songs/edit.blade.php ENDPATH**/ ?>