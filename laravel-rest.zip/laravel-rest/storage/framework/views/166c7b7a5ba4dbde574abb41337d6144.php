

<?php $__env->startSection('content'); ?>
    <h2><?php echo e($song->title); ?></h2>
    <p>
        von <b><?php echo e($song->band); ?></b>
    </p>
    <p>
        <small>
            angelegt am: <i><?php echo e($song->created_at); ?></i><br>
            geändert am: <i><?php echo e($song->updated_at); ?></i>
        </small>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gencay\Documents\laravel-projekte\laravel-rest\resources\views/songs/show.blade.php ENDPATH**/ ?>