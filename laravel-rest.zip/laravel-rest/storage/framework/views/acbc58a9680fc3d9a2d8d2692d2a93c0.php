

<?php $__env->startSection('content'); ?>
  <h2>Übersicht</h2>
  
  <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
    
    <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col"> 
        <div class="card">

          <div class="card-header">
            <h5><a href="<?php echo e(url('/songs', ['id' => $song->id])); ?>"><?php echo e($song->title); ?></a></h5>
          </div>

          <div class="card-body">
            <p class="card-title">
              von <?php echo e($song->band); ?><br>
              Label: <?php echo e($song->name); ?>

            </p>
          </div>

          <div class="card-footer d-flex justify-content-between">
            <a class="btn btn-warning" href="/songs/<?php echo e($song->id); ?>/edit">Song bearbeiten</a>
            
            <form action="<?php echo e(url('/songs', ['id' => $song->id])); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="btn btn-danger" type="submit">Song löschen</button>
            </form>
          </div>

        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gencay\Documents\laravel-projekte\laravel-rest\resources\views/songs/index.blade.php ENDPATH**/ ?>