

<?php $__env->startSection('content'); ?>
  <h2>Übersicht</h2>

  <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">

    <table class="table table-hover">
      <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><a href="/labels/<?php echo e($label->id); ?>"><?php echo e($label->name); ?></a></td>
          <td class="d-flex">
            <a href="/labels/<?php echo e($label->id); ?>/edit" class="btn btn-warning me-3">Label bearbeiten</a>

            <form action="<?php echo e(url('/labels', ['id' => $label->id])); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger">Label löschen</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gencay\Documents\laravel-projekte\laravel-rest\resources\views/labels/index.blade.php ENDPATH**/ ?>