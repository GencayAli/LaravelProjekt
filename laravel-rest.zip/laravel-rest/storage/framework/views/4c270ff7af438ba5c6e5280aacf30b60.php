

<?php $__env->startSection('content'); ?>
  <form class="row" action="/labels/<?php echo e($label->id); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="col-md-4">
        <div class="mb-3">
          <label class="form-label" for="name">Name</label>
          <input class="form-control" type="text" name="name" id="name" value="<?php echo e($label->name); ?>">
        </div>
        
        <div class="mt-5">
          <button class="btn btn-success" type="submit">Speichern</button>
        </div>

        
        
        <?php if($errors->any()): ?>
          <div class="alert alert-danger mt-5">
            <ul class="list-group">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item bg-transparent"> <?php echo $error; ?> </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>

      </div>
    
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gencay\Documents\laravel-projekte\laravel-rest\resources\views/labels/edit.blade.php ENDPATH**/ ?>